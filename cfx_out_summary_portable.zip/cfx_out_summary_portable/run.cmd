@echo off
setlocal
rem Portable runner: uses the bundled Python, nothing to install.
rem Drag one or more folders onto this file, or run:  run.cmd "E:\Sims" "E:\More sims" [--latest-only] [-o out.csv]
set "HERE=%~dp0"
if "%~1"=="" (
  echo Drag one or more simulation folders onto run.cmd, or run it from a terminal:
  echo   run.cmd "E:\Sims folder" [--latest-only] [-o results.csv]
  pause
  exit /b 1
)
echo %* | findstr /C:" -o" /C:"--output" >nul
if errorlevel 1 (
  "%HERE%python\python.exe" "%HERE%cfx_out_summary.py" %* -o "%HERE%cfx_sim_settings.csv"
) else (
  "%HERE%python\python.exe" "%HERE%cfx_out_summary.py" %*
)
echo.
pause
