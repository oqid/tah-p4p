CFX .out summary - portable

No Python install needed; a self-contained Python 3.12 (Windows 64-bit) is in the python folder.

Easiest: drag one or more simulation folders onto run.cmd.
It searches them (and all subfolders) for CFX *.out files and writes
cfx_sim_settings.csv next to run.cmd.

From a terminal:
  run.cmd "E:\50cc sims" "E:\35cc sims" -o results.csv
  run.cmd "E:\sims" --latest-only     (newest run per Workbench project only)

Keep the whole folder together; run.cmd needs the python folder beside it.
