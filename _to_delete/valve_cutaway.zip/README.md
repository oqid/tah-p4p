# Valve cutaway figures (35 cc, 120 BPM)

Dumont et al. (2007) Fig. 5 style: flow at five systolic snapshots with the valve geometry in view.
Built only from data already on disk: the haemolysis pathline exports (`35cc_inputs/120BPM`)
and the per-phase STP fluid domains (`E:\35cc Retry\3D 35cc STP Files`). No new ANSYS exports.

## Figures (`figures/`)
| File | What it shows |
|---|---|
| `valve_section_zoom_35cc_120` | Mid-plane section of the valve and outflow tract at each phase: speed, in-plane flow direction, reversed axial flow (dashed), and regions no path reached (grey). |
| `valve_section_full_35cc_120` | Same plane across the whole chamber (washout/stagnation overview for the supervisor's request). |
| `valve_cutaway3d_35cc_120` | 3D cutaway: rear half of the domain, opaque disc and pivots, 700 pathlines per phase coloured by scalar shear stress. |

The section plane contains the outflow axis and the disc normal, and is perpendicular to the disc's hinge axis.
It passes through both the inflow and outflow ports, so it is the chamber's natural mid-plane.
Disc openings measured from the STPs: 28.3, 53.3, 75.0, 53.5, 28.7° from closed.

## How the section fields are made
* Every pathline point within ±1 mm of the plane is used, Gaussian-weighted by distance from the plane.
* Speed is the exported `Velocity` magnitude. Direction comes from consecutive points on each line (the export has no vector components).
* Values are averaged onto a 0.5 mm grid by normalised Gaussian convolution (σ = 0.7 mm).
* The white lines are drawn by `streamplot` from the in-plane direction only (unit length), so they show direction, not speed.
* The grey "no path" regions are not measurements. Inlet-seeded paths in a frozen (steady) field cannot enter a closed recirculation zone, so a large void beside the disc is consistent with separated or recirculating flow. Small voids can also be sampling gaps (about 4,900 paths per phase).

## Rerun (from this folder)
Needs `numpy scipy matplotlib gmsh pyvista`.
```
python load.py         # CSV -> ph*.npz   (CSV_DIR env var overrides ..\35cc_inputs\120BPM)
python geom.py         # STP -> geom*.pkl (STP_DIR env var overrides E:\35cc Retry\3D 35cc STP Files)
python fields.py       # section fields  -> field*.pkl
python fig_section.py  # 2D figures
python render3d.py 16  # repeat for 33 50 66 83
python fig_3d.py       # 3D figure
```
The face IDs for the disc (47–51) and pivots in `common.py` come from these STPs. Check them again if the CAD changes.
For 171 BPM, point `CSV_DIR` at `35cc_inputs\171BPM` (the geometry is the same).
