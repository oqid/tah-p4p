"""Curated, report-sized figures (16 cm wide) telling the 50 cc hemolysis story.

    python report_figures.py ..\\z_inputs                (50 cc, 120 bpm)
    python report_figures.py ..\\z_inputs --bpm 120 --outdir report_figs

Storyline (see FIGURE_GUIDE.md for captions and the sentence each one supports):
  F1  operating conditions: flow, valve opening, valve-jet speed per phase
  F2  mechanism: HI3 follows valve-jet speed, not flow; stress term dominates
  F3  spatial: path stress (top) and where the dose is deposited (bottom)
  F4  timing: dose is deposited in the last tens of ms -> quasi-steady defence
  F5  path completion: paths stopping at the valve ring
  F6  35 cc hypothesis from similarity scaling
PNG (300 dpi) + PDF are written for each.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mt
from matplotlib.colors import LogNorm
import numpy as np
import pandas as pd

import explore_core as ec
import explore_hemolysis as eh
import operating_point as op
import scaling

HERE = Path(__file__).resolve().parent
W = 6.3  # inches, ~16 cm text width
plt.rcParams.update({"font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.8,
                     "savefig.dpi": 300, "lines.linewidth": 1.5})
PC, PM = eh.PHASE_COLOURS, eh.PHASE_MARKERS
BLUE, PINK, INK, MUTED = "#2E6DB4", "#C2477F", eh.INK, eh.MUTED


def save(fig, out, name):
    fig.savefig(out / f"{name}.png")
    fig.savefig(out / f"{name}.pdf")
    plt.close(fig)


def label_points(ax, x, y, labels, dx=4, dy=3):
    for xi, yi, l in zip(x, y, labels):
        ax.annotate(l, (xi, yi), xytext=(dx, dy), textcoords="offset points", fontsize=6.5, color=INK)


def logfmt(ax, axis="y"):
    a = ax.yaxis if axis == "y" else ax.xaxis
    a.set_minor_formatter(mt.NullFormatter())


# ---------------------------------------------------------------------------

def f1_operating(case, opt, out):
    st = op.stroke(bpm=case.bpm)
    fig, axs = plt.subplots(1, 3, figsize=(W, 2.3), constrained_layout=True)
    ph = opt.phase_pct.to_numpy()
    ax = axs[0]
    ax.plot(st["t"] / st["t"][-1] * 100, st["Q_ml_s"], color=MUTED, lw=1.2)
    for i, r in opt.iterrows():
        ax.plot(r.phase_pct, r.Q_ml_s, marker=PM[i], color=PC[i], ms=6, ls="none")
    ax.set_xlabel("Systolic phase [%]"); ax.set_ylabel("Inlet flow Q [mL/s]")
    ax.set_title("a) Diaphragm inflow")
    ax.text(0.5, 0.06, f"{st['bc_stroke_volume_ml']:.1f} mL/systole\n≈ {st['bc_cardiac_output_l_min']:.1f} L/min @ {case.bpm:g} bpm",
            transform=ax.transAxes, ha="center", fontsize=6.5, color=MUTED)
    ax.set_xlim(0, 100); ax.set_ylim(0, None)

    ax = axs[1]
    for i, r in opt.iterrows():
        ax.bar(i, r.valve_open_frac * 100, color=PC[i], width=0.7)
        ax.text(i, r.valve_open_frac * 100 + 2, f"{r.valve_angle_deg:g}°", ha="center", fontsize=6.5, color=INK)
    ax.set_xticks(range(len(ph)), [f"{p:g}" for p in ph])
    ax.set_xlabel("Systolic phase [%]"); ax.set_ylabel("Open orifice area [%]")
    ax.set_title("b) Valve opening")
    ax.set_ylim(0, 90)

    ax = axs[2]
    p99 = [np.percentile(s.vel, 99) for s in case.all_snaps]
    for i, r in opt.iterrows():
        ax.plot(r.U_jet_proxy_m_s, p99[i], marker=PM[i], color=PC[i], ms=6, ls="none")
    label_points(ax, opt.U_jet_proxy_m_s, p99, [f"{p:g}%" for p in ph])
    ax.set_xlabel("Valve-jet proxy U_jet [m/s]")
    ax.set_ylabel("CFD path speed, P99 [m/s]")
    ax.set_title("c) Jet proxy vs CFD speed")
    ax.set_xlim(0.5, 5.2); ax.set_ylim(1.4, 3.5)
    save(fig, out, "F1_operating_conditions")


def f2_mechanism(case, opt, out):
    t = case.table
    ph = t.phase_pct.to_numpy()
    fig, axs = plt.subplots(2, 2, figsize=(W, 4.9), constrained_layout=True)
    ax = axs[0, 0]
    y = t.GW_HI3_mean.to_numpy()
    err = np.vstack([y - t.GW_HI3_mean_ci_lo, t.GW_HI3_mean_ci_hi - y])
    ax.errorbar(ph, y, yerr=err, marker="o", color=BLUE, capsize=2.5, label="all exported paths")
    ax.plot(ph, t.GW_HI3_mean_completed_paths, marker="o", mfc="white", color=BLUE, lw=1,
            label="outlet-reaching paths only")
    ax.set_yscale("log"); logfmt(ax)
    ax.set_xlabel("Systolic phase [%]"); ax.set_ylabel("Mean per-path HI3 [%] (GW)")
    ax.set_title("a) HI3 is U-shaped through systole")
    ax.legend(loc="upper center")
    ax.set_ylim(1.5e-5, 6e-4)
    ax.set_yticks([2e-5, 5e-5, 1e-4, 2e-4, 5e-4], ["2e-5", "5e-5", "1e-4", "2e-4", "5e-4"])

    for ax, x, xl, ttl in ((axs[0, 1], opt.Q_ml_s.to_numpy(), "Instantaneous inflow Q [mL/s]",
                            "b) HI3 falls as flow rises…"),
                           (axs[1, 0], opt.U_jet_proxy_m_s.to_numpy(), "Valve-jet proxy [m/s]",
                            "c) …but rises steadily with valve-jet speed")):
        for i in range(len(ph)):
            ax.plot(x[i], y[i], marker=PM[i], color=PC[i], ms=6.5, ls="none")
        label_points(ax, x, y, [f"{p:g}%" for p in ph])
        sl, ic = np.polyfit(np.log(x), np.log(y), 1)
        r = np.corrcoef(np.log(x), np.log(y))[0, 1]
        xx = np.geomspace(x.min() * 0.9, x.max() * 1.1, 20)
        ax.plot(xx, np.exp(ic) * xx ** sl, color=MUTED, lw=0.9, ls="--")
        ax.text(0.04 if sl > 0 else 0.96, 0.95, f"slope {sl:.1f}, r = {r:.2f}", transform=ax.transAxes,
                ha="left" if sl > 0 else "right", va="top", fontsize=6.8, color=MUTED)
        ax.set_xscale("log"); ax.set_yscale("log"); logfmt(ax); logfmt(ax, "x")
        ax.set_xlabel(xl); ax.set_ylabel("Mean HI3 [%] (GW)"); ax.set_title(ttl)
        ax.set_ylim(3e-5, 4e-4)
        yt = [3e-5, 1e-4, 3e-4]
        ax.set_yticks(yt, ["3e-5", "1e-4", "3e-4"])
        xt = [150, 200, 250, 300, 350] if x.max() > 50 else [1, 2, 3, 4, 5]
        ax.set_xticks(xt, [str(v) for v in xt])
    ax = axs[1, 1]
    ref_i = int(np.argmin(np.abs(ph - 50)))
    dec = [eh.log_decomposition(case.snaps[ref_i].paths, s.paths) for s in case.snaps]
    x = np.arange(len(ph))
    ax.bar(x - 0.19, [d["time"] for d in dec], 0.36, color="#8FB8DE", label="transit-time term β·Δ⟨ln T⟩")
    ax.bar(x + 0.19, [d["stress"] for d in dec], 0.36, color="#D98CB3", label="stress term α·Δ⟨ln τ_eff⟩")
    ax.plot(x, [d["total_geo"] for d in dec], "_", color="k", ms=14, mew=1.6, label="total")
    ax.axhline(0, color=MUTED, lw=0.7)
    ax.set_xticks(x, [f"{p:g}" for p in ph]); ax.set_xlabel("Systolic phase [%]")
    ax.set_ylabel(f"log₁₀ change vs {ph[ref_i]:g}%")
    sec = ax.secondary_yaxis("right", functions=(lambda l: 10 ** l, np.log10))
    sec.set_ylabel("× factor"); sec.set_yticks([1, 2, 4, 8, 16])
    sec.yaxis.set_major_formatter(mt.FormatStrFormatter("%g"))
    ax.set_title("d) Stress, not residence time, drives it")
    ax.legend(loc="upper center", fontsize=6.3)
    save(fig, out, "F2_mechanism")


def _path_stress(ax, s, n=200, seed=0):
    rng = np.random.default_rng(seed)
    pick = rng.choice(s.n_paths, size=min(n, s.n_paths), replace=False)
    mask = np.isin(s.pid, pick)
    xyz = s.xyz[mask] * 1e3
    tau = np.maximum(s.tau[mask], 1e-3)
    o = np.argsort(tau)
    return ax.scatter(xyz[o, 0], xyz[o, 2], c=tau[o], s=0.6, cmap="magma", norm=LogNorm(1e-2, 1e2),
                      rasterized=True, linewidths=0)


def f3_spatial(case, opt, out, phases=(16.67, 50.0, 83.0)):
    snaps = [s for s in case.all_snaps if s.phase in phases]
    allxyz = np.vstack([s.xyz for s in case.all_snaps]) * 1e3
    lo, hi = allxyz.min(0) - 1, allxyz.max(0) + 1
    edges = [np.arange(lo[k], hi[k] + 1.0, 1.0) for k in range(3)]
    fig, axs = plt.subplots(2, len(snaps), figsize=(W, 3.75), constrained_layout=True, sharex=True, sharey=True)
    cmap = plt.get_cmap("magma_r").copy(); cmap.set_under("#EDEDED")
    for j, s in enumerate(snaps):
        r = opt[np.isclose(opt.phase_pct, s.phase)].iloc[0]
        ax = axs[0, j]
        m1 = _path_stress(ax, s)
        ax.set_title(f"{s.phase:g}% systole · valve {r.valve_angle_deg:g}°")
        ax = axs[1, j]
        xyz = s.xyz * 1e3
        mid = xyz.copy(); mid[1:] = 0.5 * (xyz[1:] + xyz[:-1])
        inner = s.inner("GW")
        H, _, _ = np.histogram2d(mid[:, 0], mid[:, 2], bins=[edges[0], edges[2]], weights=inner)
        H /= inner.sum()
        occ, _, _ = np.histogram2d(xyz[:, 0], xyz[:, 2], bins=[edges[0], edges[2]])
        H = np.where(occ > 0, np.maximum(H, 1e-9), np.nan)
        m2 = ax.pcolormesh(edges[0], edges[2], H.T, cmap=cmap, norm=LogNorm(1e-5, 0.1), rasterized=True)
        H3, _ = np.histogramdd(mid, bins=edges, weights=inner)
        occ3, _ = np.histogramdd(xyz, bins=edges)
        vals = np.sort(H3[occ3 > 0])[::-1] / inner.sum()
        k50 = np.searchsorted(np.cumsum(vals), 0.5) + 1
        ax.text(0.03, 0.03, f"50% of dose in\n{100 * k50 / len(vals):.2f}% of volume", transform=ax.transAxes,
                fontsize=6.3, color=INK, bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.5))
        ax.set_xlabel("X [mm]")
    for a in axs.ravel():
        a.set_aspect("equal"); a.grid(False)
    axs[0, 0].set_ylabel("Z [mm]"); axs[1, 0].set_ylabel("Z [mm]")
    fig.colorbar(m1, ax=axs[0, :].tolist(), shrink=0.85, label="Local scalar stress [Pa]")
    fig.colorbar(m2, ax=axs[1, :].tolist(), shrink=0.85, extend="min", label="Share of linear HI3 dose\nper 1 mm column")
    save(fig, out, "F3_spatial_stress_and_dose")


def f4_timing(case, out):
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.5), constrained_layout=True)
    w = np.logspace(0, np.log10(3000), 120)
    ws = np.r_[1, 2, 5, 10, 20, 30, 50, 75, 100, 150, 200, 300, 500, 1000, 3000]
    for i, s in enumerate(case.all_snaps):
        s = s.subset(s.paths.completed.to_numpy())   # outlet-reaching paths only
        inner, tte = s.inner("GW"), s.time_to_exit() * 1e3
        o = np.argsort(tte); cum = np.cumsum(inner[o]) / inner.sum()
        rem = case.Ts * 1e3 * (1 - s.phase / 100)
        axs[0].plot(w, np.interp(w, tte[o], cum), color=PC[i], label=f"{s.phase:g}%")
        axs[0].plot(rem, np.interp(rem, tte[o], cum), marker=PM[i], color=PC[i], ms=5)
        base = s.paths.GW_HI3.mean()
        axs[1].plot(ws, [eh.truncated_hi3(s, x / 1e3).mean() / base for x in ws], color=PC[i])
        axs[1].plot(rem, eh.truncated_hi3(s, rem / 1e3).mean() / base, marker=PM[i], color=PC[i], ms=5)
    axs[0].set_title("a) Dose deposited before exit")
    axs[0].set_xlabel("Time before path exit [ms]"); axs[0].set_ylabel("Cumulative share of dose")
    axs[0].legend(title="phase", loc="upper left", fontsize=6.3, title_fontsize=6.5)
    axs[1].set_title("b) HI3 retained in a final window")
    axs[1].set_xlabel("Exposure window before exit [ms]"); axs[1].set_ylabel("HI3(window) / HI3(full)")
    for a in axs:
        a.set_xscale("log"); a.set_ylim(0, 1.03)
    save(fig, out, "F4_damage_timing")


def f5_completion(case, out):
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.6), constrained_layout=True,
                            gridspec_kw=dict(width_ratios=[1.15, 1]))
    fr, sh, ph = [], [], []
    for i, s in enumerate(case.all_snaps):
        p = s.paths; inc = ~p.completed.to_numpy()
        E = p[["end_x", "end_z"]].to_numpy() * 1e3
        axs[0].scatter(E[~inc, 0], E[~inc, 1], s=1, color="#C8C8C8", rasterized=True,
                       label="ends on outlet" if i == 0 else None)
        axs[0].scatter(E[inc, 0], E[inc, 1], s=5 + 60 * p.GW_HI3.to_numpy()[inc] / p.GW_HI3.max(),
                       marker=PM[i], facecolor="none", edgecolor=PC[i], lw=0.6, label=f"{s.phase:g}% stops early")
        fr.append(inc.mean() * 100); sh.append(p.GW_HI3[inc].sum() / p.GW_HI3.sum() * 100); ph.append(s.phase)
    axs[0].set_aspect("equal"); axs[0].set_xlabel("X [mm]"); axs[0].set_ylabel("Z [mm]")
    axs[0].set_title("a) Path end points (size ∝ HI3)")
    axs[0].legend(fontsize=5.8, loc="upper left", markerscale=1.0, handletextpad=0.2, labelspacing=0.3)
    axs[0].set_xlim(-38, 32); axs[0].set_ylim(-8, 30)
    x = np.arange(len(ph))
    axs[1].bar(x - 0.2, fr, 0.38, color="#BDBDBD", label="% of paths")
    axs[1].bar(x + 0.2, sh, 0.38, color=BLUE, label="% of summed HI3")
    for xi, (a, b) in enumerate(zip(fr, sh)):
        axs[1].text(xi - 0.2, a + 1, f"{a:.1f}", ha="center", fontsize=6)
        axs[1].text(xi + 0.2, b + 1, f"{b:.0f}", ha="center", fontsize=6)
    axs[1].set_xticks(x, [f"{p:g}" for p in ph]); axs[1].set_xlabel("Systolic phase [%]")
    axs[1].set_ylabel("%"); axs[1].set_title("b) Early-stopping paths vs their HI3")
    axs[1].legend(loc="upper left", ncol=2); axs[1].set_ylim(0, 62)
    save(fig, out, "F5_path_completion")


def f6_scaling(case, out):
    t = case.table
    ph = t.phase_pct.to_numpy()
    sc = scaling.scenarios(case.bpm)
    cols = dict(zip(sc, ("#5E8C31", "#B8860B")))
    regs = list(scaling.REGIMES)
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.6), constrained_layout=True)
    ax = axs[0]
    ax.plot(ph, t.GW_HI3_mean, marker="o", color=BLUE, label="50 cc CFD")
    for scen, r in sc.items():
        g = [r[f"HI3_ratio|GW|{k}"] for k in regs]
        ax.fill_between(ph, t.GW_HI3_mean * min(g), t.GW_HI3_mean * max(g), color=cols[scen], alpha=0.3, lw=0,
                        label=f"35 cc, {scen}")
    ax.set_yscale("log"); logfmt(ax)
    ax.set_xlabel("Systolic phase [%]"); ax.set_ylabel("Mean HI3 [%] (GW)")
    ax.set_title("a) Predicted 35 cc band")
    ax.legend(loc="upper center", fontsize=6.3)
    ax = axs[1]
    short = ["visc.", "BL", "inert."]
    xt, xl = [], []
    for j, (scen, r) in enumerate(sc.items()):
        for gi, g in enumerate(regs):
            xp = j * 4 + gi; xt.append(xp); xl.append(short[gi])
            for k, mk in (("GW", "o"), ("HO", "s"), ("TZ", "^")):
                ax.plot(xp, r[f"HI3_ratio|{k}|{g}"], marker=mk, ms=5.5, ls="none", color=cols[scen],
                        mfc=cols[scen] if k == "GW" else "white", label=k if (j == 0 and gi == 0) else None)
        ax.text(j * 4 + 1, 0.43, scen, ha="center", fontsize=6.5, color=cols[scen], fontweight="bold")
    ax.axhline(1, color=MUTED, lw=0.8)
    ax.axhline(1.56, color="#7A5195", ls=":", lw=1)
    ax.text(6.6, 1.47, "Marom 2014 SA ratio", fontsize=5.8, color="#7A5195", ha="right", va="top")
    ax.set_yscale("log"); ax.set_ylim(0.4, 3); logfmt(ax)
    ax.set_yticks([0.5, 0.75, 1, 1.5, 2, 3], ["0.5", "0.75", "1", "1.5", "2", "3"])
    ax.set_xticks(xt, xl)
    ax.set_ylabel("Predicted HI3 ratio 35/50")
    ax.set_title("b) Ratio by stress scaling and model")
    leg = ax.legend(loc="upper left", fontsize=6.3)
    for h in leg.legend_handles:
        h.set_color(MUTED)
    save(fig, out, "F6_35cc_hypothesis")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", type=Path)
    ap.add_argument("--label", default="50 cc")
    ap.add_argument("--bpm", type=float, default=120.0)
    ap.add_argument("--outdir", type=Path, default=HERE / "report_figs")
    a = ap.parse_args(argv)
    a.outdir.mkdir(parents=True, exist_ok=True)
    case = eh.Case(a.label, a.folder, a.bpm, 0.5, eh.CASE_COLOURS[0])
    opt = op.table([s.phase for s in case.all_snaps], bpm=a.bpm)
    opt["cfd_speed_p99_m_s"] = [np.percentile(s.vel, 99) for s in case.all_snaps]
    opt["GW_HI3_mean"] = case.table.GW_HI3_mean.to_numpy()
    opt["GW_HI3_mean_completed"] = case.table.GW_HI3_mean_completed_paths.to_numpy()
    opt.to_csv(a.outdir / "operating_points.csv", index=False)
    plt.rcParams["axes.grid"] = True
    f1_operating(case, opt, a.outdir)
    f2_mechanism(case, opt, a.outdir)
    f3_spatial(case, opt, a.outdir)
    f4_timing(case, a.outdir)
    f5_completion(case, a.outdir)
    f6_scaling(case, a.outdir)
    print(f"done -> {a.outdir}")


if __name__ == "__main__":
    main()
