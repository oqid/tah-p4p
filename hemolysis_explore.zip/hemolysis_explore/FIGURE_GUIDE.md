# Figure guide: which figures go in the report, and what each one argues

Your three favourites are the backbone of the set:
* `04_damage_map_xz` and `07_spatial_path_stress` → combined into **F3**
* `01_phase_mechanism` → rebuilt as **F2**, now using the valve angles

All report figures are 16 cm wide (page text width), with PNG at 300 dpi plus a vector PDF, in `report_figs/`. Regenerate them with:

```powershell
python report_figures.py ..\z_inputs --bpm 120
```

The suggested order follows the argument:

**operating point → mechanism → location → method check → 35 cc prediction**

---

## F1 — Operating conditions per snapshot (Methods / start of Results)

**Claim:** the five snapshots differ in two ways, the inflow and the valve opening. Their combination sets how fast the blood moves through the valve.

**Suggested caption:**
> Operating conditions of the five steady systolic snapshots (50 cc, 120 bpm).
> (a) Diaphragm inflow, Q = v·A_dome. The prescribed normal speed v = πS/(2T_s)·sin(πφ) is applied over the revolved half-sine dome. Integrated over systole this gives 55.5 mL, or 6.7 L/min.
> (b) Outlet-valve disc angle (0° = closed) and the geometric open area, A_out(1 − cos θ), with A_out = 4.648 cm².
> (c) The valve-jet speed proxy U_jet = Q / [A_out(1 − cos θ)] against the 99th-percentile path speed from CFD.

**What to say:**
* The proxy is crude: it ignores the jet contraction and the valve's real gap shape. Even so, it ranks the five phases in exactly the same order as the CFD velocities.
* At 16.67% and 83% the inflow is about half the mid-systole value. But the disc is only about 25° open, so the open area is about 8× smaller, and the jet is 3–4.5× faster.

## F2 — Mechanism (the centrepiece of the Results)

**Claim:** the U-shaped HI3 through systole is caused by the partially open valve. Neither flow rate nor residence time explains it.

**Suggested caption:**
> (a) Mean per-path HI3 (Giersiepen–Wurzinger constants, 95% bootstrap CI) for all exported paths and for outlet-reaching paths only.
> (b) HI3 against instantaneous inflow.
> (c) HI3 against the valve-jet proxy.
> (d) Exact log decomposition of the change in geometric-mean HI3 relative to 50% systole. Since HI3 = A·T^β·τ_eff^α on every path, the change splits into a transit-time term β·Δ⟨ln T⟩ and a stress term α·Δ⟨ln τ_eff⟩.

**What to say:**
* HI3 is *anti*-correlated with flow (r = −0.82). Against valve-jet speed it is almost perfectly monotonic: log–log slope 1.2, r = 0.99 across five points.
* The stress term accounts for ×4.6 at 16.67% and ×12 at 83%. Transit time adds at most ×1.9.
* Design implication: damage per pass is governed by how far the valve is open while blood is being ejected.
* Mention that HO and TZ constants rank the phases identically (see `outputs/.../01_phase_mechanism`).

## F3 — Where the stress and the damage are (your favourite)

**Claim:** high stress follows the paths into the outflow tract, and nearly all of the damage is deposited in a small region at the valve.

**Suggested caption:**
> Top: local scalar stress along 200 randomly sampled paths at early, mid and late systole (X–Z projection). Bottom: linear HI3 dose, A^(1/β)·τ^(α/β)·dt, deposited per 1 mm column, as a share of each phase's total. Grey = region visited by paths.

**What to say:**
* Half of the dose sits in 0.03–0.45% of the visited volume, at the valve ring and in the outflow tract. The chamber body contributes essentially nothing.
* At 25° opening the dose forms a ring at the valve. At 75° it spreads into the outflow jet.
* The X–Y version and all five phases are in `outputs/.../04_damage_map_*.png` (Appendix).
* `hotspots.csv` gives voxel coordinates. Placing a CFD-Post point or contour there would make a strong complementary image of the valve-gap velocity.

## F4 — Damage timing → why the quasi-steady approach is defensible (Discussion)

**Claim:** paths are slow to cross the chamber, but damage accumulates only in the last few tens of milliseconds. So violating the frozen-flow assumption over the long, slow part of a path barely changes HI3.

**Suggested caption:**
> Outlet-reaching paths only.
> (a) Cumulative share of linear dose against time remaining before the path exits.
> (b) Mean HI3 counting only the dose deposited within a final window, relative to the full-path value.
> Markers show the time left in systole after each snapshot, T_s(1 − φ).

**What to say:**
* 59–100% of paths take longer to exit than the time remaining in systole, so a frozen-field path is not physically realisable.
* Yet ≥ 90% of each phase's mean HI3 is accumulated within that remaining time.
* This is the honest way to state the limitation and bound its effect.

## F5 — Path completion (Methods verification / Limitations)

**Claim:** a small number of streamlines stop at the valve ring. They carry a disproportionate share of HI3, so results are reported with and without them.

**Suggested caption:**
> (a) Path end points. Grey points end on the outlet plane. Coloured markers end more than 1 mm from it, sized by path HI3.
> (b) Share of paths that stop early, and their share of summed HI3.

**What to say:**
* 1.4–9.6% of paths end on a ring about 16–20 mm across at the valve seat or disc edge. There the flow is slow (about 0.3 m/s) and the stress high (median about 49 Pa).
* They carry 18–45% of summed HI3.
* Excluding them lowers mean HI3 by 10–45%, but leaves the phase trend unchanged (F2a).
* Likely cause: streamlines entering the no-slip near-wall region of the narrow valve gap and terminating there. This is an integration artefact, not a physical end point.

## F6 — 35 cc hypothesis (end of Results or Discussion; replace with measured data later)

**Claim:** similarity scaling makes a falsifiable prediction for 35 cc. At the same rate, damage per pass stays the same or falls, but output drops. Restoring output roughly doubles damage per pass.

**Numbers for the text:**
* Every length is scaled by 0.888.
* At 120 bpm the inlet BC gives 38.9 mL per systole, or 4.66 L/min (×0.70).
* Matching 6.66 L/min needs 171 bpm.
* Predicted GW HI3 ratio: 0.56–1.0 at 120 bpm, and 1.8–2.4 at 171 bpm (1.5–2.0 with HO/TZ).
* For context, Marom et al. found a 1.56× higher SA median for 35 cc than 50 cc.

When the 35 cc runs exist, `explore_hemolysis.py` with two `--case` arguments produces `07_size_comparison` with these bands overlaid.

---

## Appendix candidates (already generated)

* `02_stress_time_map`: per-path τ_eff vs transit with iso-HI3 lines. A good bridge between F2 and F3 if you have room.
* `05_numerical_audit` c–d: stress-sampling and segment-length checks.
* The full five-phase `04_damage_map_xz` / `_xy`.
* From `haem5_paper_comparison`: SA density (01), Taskin model sensitivity (03) and subset stability (11).

## Methods notes from your answers (worth one sentence each in the report)

* **Diaphragm:** an Inventor parametric half-sine, x = 2Lt and y = A·Pump·sin(2πt) for t ∈ [0, 0.5], revolved, with L = 56.211 mm and A = 20 mm.
  - Pump equals the systolic fraction, so the dome *height* is linear in phase.
  - The inlet *speed* follows the sinusoidal displacement law. Mention both.
* **The inlet BC, not the CAD sweep, sets the flow.** Over the full stroke the dome's own volume change is only 23.0 mL. The velocity BC, applied normal to the whole dome surface, delivers 55.5 mL per systole.
  - That is fine for steady snapshots, but say so explicitly.
  - It is also why the delivered output (6.7 L/min) is close to the nominal 50 cc × 120 bpm.
* **Solver:** steady SST, physical timescale 5×10⁻⁴ s, converged after 1,234 accumulated pseudo-timesteps, no-slip walls.
  - Stress = molecular viscosity × strain rate. Reynolds stresses are not included.
  - Note that this likely *under*-estimates the stress experienced in the turbulent jet. That is acceptable for a relative 50/35 comparison, but it matters for absolute NIH.
* **Systole** is assumed to be 50% of the cycle (250 ms at 120 bpm).
